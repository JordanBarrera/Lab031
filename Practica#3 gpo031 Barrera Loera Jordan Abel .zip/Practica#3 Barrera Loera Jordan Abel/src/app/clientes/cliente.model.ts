export interface Cliente{
    id: number;
    nombre: string;
    curp: string;
    direccion: string;
    sexo: number;
}

export interface Grupo{
    id: number;
    sexo: string;
}